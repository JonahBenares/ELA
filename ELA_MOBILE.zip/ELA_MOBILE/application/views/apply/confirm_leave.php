            <div class="content">
                <div class="container-fluid">                    
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="card" style="padding: 30px">
                                <center>
                                    <h1 style="font-size:100px;color:#ca4a4a;" class="mt2 animated pulse infinite "><span class="ti-alert"></span></h1>
                                    <h3>Are you sure you want to file leave?</h3>
                                    <hr>
                                    <input type="button" class="btn btn-default btn-fill" name="" value="No">
                                    <input type="button" class="btn btn-super-danger btn-fill" name="" value="Yes">
                                </center>
                            </div>
                        </div>
                    </div>                    
                </div>
            </div>
        </div>
    </div>


</body>
