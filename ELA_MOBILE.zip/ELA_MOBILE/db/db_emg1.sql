-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 10, 2018 at 08:27 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_emg`
--

-- --------------------------------------------------------

--
-- Table structure for table `rtd_info`
--

CREATE TABLE IF NOT EXISTS `rtd_info` (
`rtd_id` int(11) NOT NULL,
  `interval_time` varchar(20) DEFAULT NULL,
  `price_node` varchar(20) DEFAULT NULL,
  `megawatts` decimal(10,2) NOT NULL DEFAULT '0.00',
  `lmp` decimal(10,2) NOT NULL DEFAULT '0.00',
  `loss_factor` decimal(10,2) NOT NULL DEFAULT '0.00',
  `upload_time` varchar(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rtd_info`
--

INSERT INTO `rtd_info` (`rtd_id`, `interval_time`, `price_node`, `megawatts`, `lmp`, `loss_factor`, `upload_time`) VALUES
(1, '2018-09-06 23:55', '06CENPRI_U01', '0.00', '284.56', '1.05', '2018-09-07 10:01:53'),
(2, '2018-09-06 23:55', '06CENPRI_U02', '0.00', '284.56', '1.05', '2018-09-07 10:01:53'),
(3, '2018-09-06 23:55', '06CENPRI_U03', '0.00', '284.56', '1.05', '2018-09-07 10:01:53'),
(4, '2018-09-06 23:55', '06CENPRI_U04', '0.00', '284.56', '1.05', '2018-09-07 10:01:53'),
(5, '2018-09-06 23:55', '06CENPRI_U05', '0.00', '284.56', '1.05', '2018-09-07 10:01:53');

-- --------------------------------------------------------

--
-- Table structure for table `rtd_other`
--

CREATE TABLE IF NOT EXISTS `rtd_other` (
`other_id` int(11) NOT NULL,
  `rtd_date` varchar(20) DEFAULT NULL,
  `rtd_hour` varchar(20) DEFAULT NULL,
  `actual_load` decimal(10,2) NOT NULL DEFAULT '0.00',
  `metered_q` decimal(10,2) NOT NULL DEFAULT '0.00',
  `bcq` decimal(10,2) NOT NULL DEFAULT '0.00',
  `upload_time` varchar(20) DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`user_id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `fullname` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `rtd_info`
--
ALTER TABLE `rtd_info`
 ADD PRIMARY KEY (`rtd_id`);

--
-- Indexes for table `rtd_other`
--
ALTER TABLE `rtd_other`
 ADD PRIMARY KEY (`other_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `rtd_info`
--
ALTER TABLE `rtd_info`
MODIFY `rtd_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `rtd_other`
--
ALTER TABLE `rtd_other`
MODIFY `other_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
